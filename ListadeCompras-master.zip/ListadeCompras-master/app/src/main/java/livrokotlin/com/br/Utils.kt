package livrokotlin.com.br

val produtosGlobal = mutableListOf<Produto>()